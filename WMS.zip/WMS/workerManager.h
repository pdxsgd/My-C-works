//
// Created by pdxsgd on 2026/3/27.
//

#ifndef WMS_WORKERMANAGER_H
#define WMS_WORKERMANAGER_H
#pragma once
using namespace std;
#include <iostream>
#include "workers.h"
#include "bosses.h"
#include "employees.h"
#include "managers.h"

class workerManager {
public:
    //构造
    workerManager();
    //展示菜单
    void showMenu();
    //退出系统
    void exitSystem();
    //职工人数
    int m_workerNum;
    //职工数组
    workers ** m_workersArray;
    //添加员工
    void addWorkers();
    //析构
    ~workerManager();
};


#endif //WMS_WORKERMANAGER_H