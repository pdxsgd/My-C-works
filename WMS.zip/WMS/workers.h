//
// Created by pdxsgd on 2026/3/27.
//

#ifndef WMS_WORKS_H
#define WMS_WORKS_H

#include <iostream>
using namespace std;
#pragma once


//抽象职工基类
class workers {
public:
    //显示个人信息
    virtual  void showInfo()=0;

    //显示部门信息
    virtual string getDepaName()=0;

    int m_id;
    string m_name;
    int m_DepaId;


};


#endif //WMS_WORKS_H