//
// Created by pdxsgd on 2026/3/27.
//

#include "bosses.h"

bosses::bosses(int id,string name,int did) {
    this->m_id = id;
    this->m_name = name;
    this->m_DepaId = did;

}

void bosses::showInfo() {
    cout << "职工姓名：" << this->m_name;
    cout << "\t职工编号：" << this->m_id;
    cout << "\t岗位：" << this->getDepaName();
    cout << "\t工作：" << "管理整个公司" << endl;
}

string bosses::getDepaName() {
    return "老板";
}