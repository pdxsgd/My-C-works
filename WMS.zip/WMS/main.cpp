#include <iostream>

#include "employees.h"
#include "workers.h"
#include "workerManager.h"
using namespace std;

int main() {
    workers * wk;
    wk = new employees(1,"sb",1);
    wk->showInfo();

    workerManager wm;
    wm.showMenu();
    int choice = 0;
    while (true) {
        cout << "请输入您的选择："<< endl;
        cin >> choice;
        switch (choice) {
            case 0:
                wm.exitSystem();
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            default:
                break;
        }
    }
    return 0;
}