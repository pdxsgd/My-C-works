//
// Created by pdxsgd on 2026/3/27.
//

#ifndef WMS_EMPLOYEES_H
#define WMS_EMPLOYEES_H
using namespace std;
#include <iostream>
#pragma once
#include "workers.h"


class employees: public workers{
    public:
    //构造
    employees(int id,string name,int did);
    //显示个人信息
    void showInfo();
    //显示部门信息
    string getDepaName();
};


#endif //WMS_EMPLOYEES_H