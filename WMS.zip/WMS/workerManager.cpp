//
// Created by pdxsgd on 2026/3/27.
//

#include "workerManager.h"

//构造函数
workerManager::workerManager() {
    m_workerNum = 0;
    m_workersArray = NULL;
}

//show the menu
void workerManager::showMenu() {
    cout << "***********************************"<<endl;
    cout << "*******欢迎使用职工管理系统！*********"<<endl;
    cout << "***********0.退出系统***********"<< endl;
    cout << "***********1.增加职工信息***********"<< endl;
    cout << "***********2.显示职工信息***********"<< endl;
    cout << "***********3.删除离职职工***********"<< endl;
    cout << "***********4.修改职工信息***********"<< endl;
    cout << "***********5.查找职工信息***********"<< endl;
    cout << "***********6.按照编号排序***********"<< endl;
    cout << "***********7.清空所有文档***********"<< endl;
    cout << "***********************************"<<endl;
}

//退出系统
void workerManager::exitSystem() {
    cout << "欢迎下次使用！"<< endl;
    exit(0);
}

//添加职工
void workerManager::addWorkers() {
    cout << "请输入要添加的员工数量：" << endl;
    int addNum = 0;
    cin >> addNum;
    if (addNum > 0) {
        //计算新空间的大小
        int newSize = m_workerNum + addNum;
        workers ** newSpace = new workers*[newSize];
        //拷贝原数组内容
        if (m_workersArray != NULL) {
            for (int i = 0; i < m_workerNum; i++) {
                newSpace[i] = m_workersArray[i];
            }
        }
        //批量添加新员工
        for (int i = 0; i <addNum; i++) {
            int id;
            string name;
            int deSelect;
            cout << "请输入第" << i+1 <<"个员工的ID号" << endl;
            cin >> id;
            cout << "请输入第" << i+1 <<"个员工的姓名" << endl;
            cin >> name;
            cout << "请输入第" << i+1 <<"个员工的部门" << endl;
            cout << "1代表普通职工，2代表经理，3代表老板" << endl;
            cin >> deSelect;
            workers * worker = NULL;
            switch (deSelect) {
                case 1:
                    worker = new employees(id,name,deSelect);
                    break;
                case 2:
                    worker = new managers(id,name,deSelect);
                    break;
                case 3:
                    worker = new bosses(id,name,deSelect);
                default:
                    break;
            }
            newSpace[m_workerNum+i] = worker;
        }
        //删除原数组
        delete[] m_workersArray;
        m_workersArray = newSpace;
        //更新员工数量
        m_workerNum = newSize;
        cout << "成功添加" << addNum << "名新职工" << endl;1
    }
    else {
        cout << "输入有误" << endl;
    }
}

//析构函数
workerManager::~workerManager(){}
