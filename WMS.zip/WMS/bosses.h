//
// Created by pdxsgd on 2026/3/27.
//

#ifndef WMS_BOSSES_H
#define WMS_BOSSES_H
#include "workers.h"
#include <iostream>
using namespace std;
#pragma once



class bosses:public workers{
public:
    //构造
    bosses(int id,string name,int did);
    //显示个人信息
    void showInfo();
    //显示部门信息
    string getDepaName();
};


#endif //WMS_BOSSES_H