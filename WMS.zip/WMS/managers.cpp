//
// Created by pdxsgd on 2026/3/27.
//

#include "managers.h"

managers::managers(int id,string name,int did) {
    this->m_id = id;
    this->m_name = name;
    this->m_DepaId = did;

}

void managers::showInfo() {
    cout << "职工姓名：" << this->m_name;
    cout << "\t职工编号：" << this->m_id;
    cout << "\t岗位：" << this->getDepaName();
    cout << "\t工作：" << "完成老板的任务" << endl;
}

string managers::getDepaName() {
    return "经理";
}