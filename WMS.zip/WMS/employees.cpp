//
// Created by pdxsgd on 2026/3/27.
//

#include "employees.h"

employees::employees(int id,string name,int did) {
    this->m_id = id;
    this->m_name = name;
    this->m_DepaId = did;

}

void employees::showInfo() {
    cout << "职工姓名：" << this->m_name;
    cout << "\t职工编号：" << this->m_id;
    cout << "\t岗位：" << this->getDepaName();
    cout << "\t工作：" << "完成经理的任务" << endl;
}

string employees::getDepaName() {
    return "员工";
}
