//
// Created by pdxsgd on 2026/3/27.
//

#ifndef WMS_MANAGERS_H
#define WMS_MANAGERS_H
#include "workers.h"
#include <iostream>
using namespace std;
#pragma once


class managers:public workers{
public:
    //构造
    managers(int id,string name,int did);
    //显示个人信息
    void showInfo();
    //显示部门信息
    string getDepaName();
};


#endif //WMS_MANAGERS_H